import { useState } from "react";
import LoginPage from "./components/LoginPage";
import ContractPage from "./components/ContractPage";
import AdminDashboard, { AdminLogin } from "./components/AdminDashboard";
import { Contract } from "./data/contracts";

type AppState = "login" | "client" | "admin-login" | "admin";

export default function App() {
  const [state, setState] = useState<AppState>("login");
  const [contract, setContract] = useState<Contract | null>(null);

  const handleClientLogin = (c: Contract) => {
    setContract(c);
    setState("client");
  };

  const handleAdminLogin = () => {
    setState("admin-login");
  };

  const handleAdminAuthenticated = () => {
    setState("admin");
  };

  const handleLogout = () => {
    setContract(null);
    setState("login");
  };

  if (state === "login") {
    return <LoginPage onLogin={handleClientLogin} onAdminLogin={handleAdminLogin} />;
  }

  if (state === "admin-login") {
    return <AdminLogin onLogin={handleAdminAuthenticated} />;
  }

  if (state === "admin") {
    return <AdminDashboard onLogout={handleLogout} />;
  }

  if (state === "client" && contract) {
    return <ContractPage contract={contract} onLogout={handleLogout} />;
  }

  // Fallback
  setState("login");
  return <LoginPage onLogin={handleClientLogin} onAdminLogin={handleAdminLogin} />;
}
