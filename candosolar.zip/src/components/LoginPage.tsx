import { useState } from "react";
import { findContract, Contract } from "../data/contracts";

interface LoginPageProps {
  onLogin: (contract: Contract) => void;
  onAdminLogin: () => void;
}

const SunIcon = () => (
  <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
    {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, i) => (
      <line
        key={i}
        x1="60"
        y1="60"
        x2={60 + 50 * Math.cos((angle * Math.PI) / 180)}
        y2={60 + 50 * Math.sin((angle * Math.PI) / 180)}
        stroke="url(#rayGrad)"
        strokeWidth="3"
        strokeLinecap="round"
        opacity="0.7"
      />
    ))}
    <circle cx="60" cy="60" r="24" fill="url(#sunGrad)" />
    <circle cx="60" cy="60" r="20" fill="url(#sunInner)" opacity="0.8" />
    <defs>
      <radialGradient id="sunGrad" cx="40%" cy="35%" r="60%">
        <stop offset="0%" stopColor="#fde68a" />
        <stop offset="50%" stopColor="#fbbf24" />
        <stop offset="100%" stopColor="#f97316" />
      </radialGradient>
      <radialGradient id="sunInner" cx="35%" cy="30%" r="60%">
        <stop offset="0%" stopColor="#fff7ed" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#fbbf24" stopOpacity="0" />
      </radialGradient>
      <linearGradient id="rayGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#fbbf24" />
        <stop offset="100%" stopColor="#f97316" stopOpacity="0.3" />
      </linearGradient>
    </defs>
  </svg>
);

export default function LoginPage({ onLogin, onAdminLogin }: LoginPageProps) {
  const [mode, setMode] = useState<"client" | "admin">("client");
  const [projectNumber, setProjectNumber] = useState("");
  const [uniqueCode, setUniqueCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    setTimeout(() => {
      const contract = findContract(projectNumber.trim(), uniqueCode.trim());
      if (contract) {
        onLogin(contract);
      } else {
        setError("Invalid project number or access code. Please check your details and try again.");
      }
      setLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col items-center justify-center" style={{ background: "linear-gradient(160deg, #0f172a 0%, #1e293b 40%, #0c1a2e 100%)" }}>
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 60 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: Math.random() * 2 + 1 + "px",
              height: Math.random() * 2 + 1 + "px",
              top: Math.random() * 60 + "%",
              left: Math.random() * 100 + "%",
              opacity: Math.random() * 0.6 + 0.2,
            }}
          />
        ))}
        <div
          className="absolute rounded-full"
          style={{
            width: "600px",
            height: "600px",
            top: "-200px",
            right: "-150px",
            background: "radial-gradient(circle, rgba(251,191,36,0.08) 0%, rgba(249,115,22,0.04) 50%, transparent 70%)",
          }}
        />
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-48 pointer-events-none"
        style={{
          background: "linear-gradient(to top, rgba(251,191,36,0.06) 0%, transparent 100%)",
        }}
      />

      {/* Main card */}
      <div className="relative z-10 w-full max-w-md px-4">
        {/* Logo / Sun */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-24 h-24 mb-4 animate-float relative">
            <div
              className="absolute inset-0 rounded-full blur-xl"
              style={{ background: "radial-gradient(circle, rgba(251,191,36,0.5) 0%, transparent 70%)" }}
            />
            <SunIcon />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">
Ez<span style={{ color: "#fbbf24" }}>Sign</span>
          </h1>
          <p className="text-blue-300 mt-1 text-sm tracking-widest uppercase">Contract Signing Portal</p>
        </div>

        {/* Mode Toggle */}
        <div className="flex gap-1 mb-6 p-1 rounded-xl" style={{ background: "rgba(15,23,42,0.6)", border: "1px solid rgba(251,191,36,0.1)" }}>
          <button
            onClick={() => { setMode("client"); setError(""); }}
            className="flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2"
            style={{
              background: mode === "client" ? "linear-gradient(135deg, #f97316, #fbbf24)" : "transparent",
              color: mode === "client" ? "white" : "#94a3b8",
            }}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
            Client Login
          </button>
          <button
            onClick={() => { setMode("admin"); setError(""); }}
            className="flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2"
            style={{
              background: mode === "admin" ? "linear-gradient(135deg, #f97316, #fbbf24)" : "transparent",
              color: mode === "admin" ? "white" : "#94a3b8",
            }}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
            Admin Login
          </button>
        </div>

        {/* Login Card */}
        <div
          className="rounded-2xl p-8 border"
          style={{
            background: "rgba(15, 23, 42, 0.85)",
            backdropFilter: "blur(20px)",
            borderColor: "rgba(251,191,36,0.2)",
            boxShadow: "0 0 40px rgba(251,191,36,0.08), 0 20px 60px rgba(0,0,0,0.5)",
          }}
        >
          {mode === "client" ? (
            <>
              <div className="mb-6 text-center">
                <h2 className="text-xl font-semibold text-white">Welcome, Client</h2>
                <p className="text-slate-400 text-sm mt-1">Enter your project details to access system details & sign your contract</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>
                    Project Number
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </span>
                    <input
                      type="text"
                      value={projectNumber}
                      onChange={(e) => setProjectNumber(e.target.value)}
                      placeholder="e.g. SOL-2024-001"
                      required
                      className="w-full pl-10 pr-4 py-3 rounded-xl text-white placeholder-slate-500 transition-all focus:outline-none"
                      style={{
                        background: "rgba(30, 41, 59, 0.8)",
                        border: "1px solid rgba(251,191,36,0.2)",
                      }}
                      onFocus={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.6)"; e.target.style.boxShadow = "0 0 0 3px rgba(251,191,36,0.1)"; }}
                      onBlur={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.2)"; e.target.style.boxShadow = "none"; }}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>
                    Unique Access Code
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                      </svg>
                    </span>
                    <input
                      type="text"
                      value={uniqueCode}
                      onChange={(e) => setUniqueCode(e.target.value)}
                      placeholder="e.g. SUNRAY7"
                      required
                      className="w-full pl-10 pr-4 py-3 rounded-xl text-white placeholder-slate-500 transition-all focus:outline-none uppercase"
                      style={{
                        background: "rgba(30, 41, 59, 0.8)",
                        border: "1px solid rgba(251,191,36,0.2)",
                      }}
                      onFocus={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.6)"; e.target.style.boxShadow = "0 0 0 3px rgba(251,191,36,0.1)"; }}
                      onBlur={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.2)"; e.target.style.boxShadow = "none"; }}
                    />
                  </div>
                </div>

                {error && (
                  <div className="rounded-lg p-3 flex items-start gap-2" style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)" }}>
                    <svg className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p className="text-red-400 text-sm">{error}</p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl font-semibold text-white transition-all duration-200 flex items-center justify-center gap-2"
                  style={{
                    background: loading ? "rgba(251,191,36,0.4)" : "linear-gradient(135deg, #f97316, #fbbf24)",
                    boxShadow: loading ? "none" : "0 4px 20px rgba(249,115,22,0.4)",
                  }}
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Verifying...
                    </>
                  ) : (
                    <>
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                      </svg>
                      Access My Contract
                    </>
                  )}
                </button>
              </form>

              <div className="mt-6 pt-5 border-t" style={{ borderColor: "rgba(251,191,36,0.1)" }}>
                <p className="text-center text-xs text-slate-500 mb-2">Demo Access Codes</p>
                <div className="space-y-1.5">
                  {[
                    { project: "SOL-2024-001", code: "SUNRAY7" },
                    { project: "SOL-2024-002", code: "BRIGHT9" },
                    { project: "SOL-2024-003", code: "PHOTON3" },
                  ].map((demo) => (
                    <button
                      key={demo.project}
                      onClick={() => { setProjectNumber(demo.project); setUniqueCode(demo.code); setError(""); }}
                      className="w-full text-xs px-3 py-2 rounded-lg text-left transition-all"
                      style={{
                        background: "rgba(30,41,59,0.5)",
                        border: "1px solid rgba(251,191,36,0.1)",
                        color: "#94a3b8",
                      }}
                      onMouseEnter={(e) => { (e.currentTarget).style.borderColor = "rgba(251,191,36,0.3)"; (e.currentTarget).style.color = "#fbbf24"; }}
                      onMouseLeave={(e) => { (e.currentTarget).style.borderColor = "rgba(251,191,36,0.1)"; (e.currentTarget).style.color = "#94a3b8"; }}
                    >
                      <span style={{ color: "#fbbf24" }}>{demo.project}</span> / {demo.code}
                    </button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="mb-6 text-center">
                <h2 className="text-xl font-semibold text-white">Admin Access</h2>
                <p className="text-slate-400 text-sm mt-1">Manage contracts and send to clients</p>
              </div>

              <button
                onClick={onAdminLogin}
                className="w-full py-3 rounded-xl font-semibold text-white transition-all duration-200 flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: "0 4px 20px rgba(249,115,22,0.4)" }}
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                </svg>
                Go to Admin Portal
              </button>

              <div className="mt-5 text-center">
                <p className="text-xs text-slate-600">Authorized personnel only</p>
              </div>
            </>
          )}
        </div>

        <p className="text-center text-slate-600 text-xs mt-6">
          © 2024 EzSign · Secure Contract Portal · SSL Encrypted
        </p>
      </div>
    </div>
  );
}
