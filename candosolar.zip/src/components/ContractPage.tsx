import { useRef, useState, useEffect } from "react";
import { Contract } from "../data/contracts";
import SignaturePad from "signature_pad";
import { AttachmentList } from "./Attachments";

interface ContractPageProps {
  contract: Contract;
  onLogout: () => void;
}

function SunLogo() {
  return (
    <div className="w-10 h-10">
      <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
        {[0,45,90,135,180,225,270,315].map((angle, i) => (
          <line key={i} x1="60" y1="60" x2={60+48*Math.cos(angle*Math.PI/180)} y2={60+48*Math.sin(angle*Math.PI/180)} stroke="url(#hdrRay)" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
        ))}
        <circle cx="60" cy="60" r="22" fill="url(#hdrSun)" />
        <defs>
          <radialGradient id="hdrSun" cx="40%" cy="35%" r="60%">
            <stop offset="0%" stopColor="#fde68a" />
            <stop offset="60%" stopColor="#fbbf24" />
            <stop offset="100%" stopColor="#f97316" />
          </radialGradient>
          <linearGradient id="hdrRay" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#fbbf24" />
            <stop offset="100%" stopColor="#f97316" stopOpacity="0.2" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

interface SignatureBoxProps {
  onSigned: (isEmpty: boolean) => void;
  padRef: React.MutableRefObject<SignaturePad | null>;
}

function SignatureBox({ onSigned, padRef }: SignatureBoxProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [hasSignature, setHasSignature] = useState(false);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const pad = new SignaturePad(canvas, {
      penColor: "#1e40af",
      backgroundColor: "rgb(248, 250, 252)",
      minWidth: 1,
      maxWidth: 3,
    });
    padRef.current = pad;

    const handleEnd = () => {
      const empty = pad.isEmpty();
      setHasSignature(!empty);
      onSigned(empty);
    };

    pad.addEventListener("endStroke", handleEnd);

    const resizeCanvas = () => {
      const ratio = Math.max(window.devicePixelRatio || 1, 1);
      canvas.width = canvas.offsetWidth * ratio;
      canvas.height = canvas.offsetHeight * ratio;
      const ctx = canvas.getContext("2d");
      if (ctx) ctx.scale(ratio, ratio);
      pad.clear();
      setHasSignature(false);
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      pad.removeEventListener("endStroke", handleEnd);
      pad.off();
    };
  }, []);

  return (
    <div className="relative rounded-xl overflow-hidden" style={{ border: "2px solid rgba(251,191,36,0.3)", background: "#f8fafc", height: "160px" }}>
      <canvas
        ref={canvasRef}
        className="w-full h-full signature-canvas"
        style={{ display: "block", touchAction: "none", cursor: "crosshair" }}
      />
      {!hasSignature && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-center">
            <svg className="w-8 h-8 mx-auto mb-2 opacity-30" style={{ color: "#94a3b8" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
            <p className="text-slate-400 text-sm">Sign here</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ContractPage({ contract, onLogout }: ContractPageProps) {
  const sigPadRef = useRef<SignaturePad | null>(null);
  const [signed, setSigned] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [sigError, setSigError] = useState("");
  const [agreementError, setAgreementError] = useState("");
  const [sigDataUrl, setSigDataUrl] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<"contract" | "details">("details");

  const signedDate = new Date().toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  });

  const handleSigned = (isEmpty: boolean) => {
    setSigned(!isEmpty);
    if (!isEmpty) setSigError("");
  };

  const clearSignature = () => {
    sigPadRef.current?.clear();
    setSigned(false);
    setSigError("");
  };

  const handleSubmit = () => {
    let hasError = false;
    if (!agreed) {
      setAgreementError("You must agree to the terms before submitting.");
      hasError = true;
    } else {
      setAgreementError("");
    }
    if (!signed || sigPadRef.current?.isEmpty()) {
      setSigError("Please provide your signature before submitting.");
      hasError = true;
    } else {
      setSigError("");
    }
    if (hasError) return;

    setSubmitting(true);
    const dataUrl = sigPadRef.current?.toDataURL() ?? null;
    setSigDataUrl(dataUrl);

    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 1500);
  };

  if (submitted) {
    return <SuccessPage contract={contract} sigDataUrl={sigDataUrl} signedDate={signedDate} onLogout={onLogout} />;
  }

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(160deg, #0f172a 0%, #1e293b 50%, #0c1a2e 100%)" }}>
      {/* Header */}
      <header className="sticky top-0 z-50 border-b" style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(20px)", borderColor: "rgba(251,191,36,0.15)" }}>
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <SunLogo />
            <div>
              <h1 className="text-white font-bold text-lg leading-tight">EzSign</h1>
              <p className="text-xs" style={{ color: "#fbbf24" }}>Contract Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-right">
              <p className="text-slate-400 text-xs">Project</p>
              <p className="text-white text-sm font-mono font-semibold">{contract.projectNumber}</p>
            </div>
            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all"
              style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", color: "#f87171" }}
              onMouseEnter={(e) => { (e.currentTarget).style.background = "rgba(239,68,68,0.2)"; }}
              onMouseLeave={(e) => { (e.currentTarget).style.background = "rgba(239,68,68,0.1)"; }}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        {/* Welcome Banner */}
        <div className="rounded-2xl p-6 mb-6 relative overflow-hidden" style={{ background: "linear-gradient(135deg, rgba(249,115,22,0.15) 0%, rgba(251,191,36,0.1) 100%)", border: "1px solid rgba(251,191,36,0.2)" }}>
          <div className="absolute top-0 right-0 w-48 h-48 opacity-5">
            <svg viewBox="0 0 120 120" fill="none" className="w-full h-full">
              <circle cx="60" cy="60" r="40" fill="#fbbf24" />
              {[0,45,90,135,180,225,270,315].map((angle,i) => (
                <line key={i} x1="60" y1="60" x2={60+55*Math.cos(angle*Math.PI/180)} y2={60+55*Math.sin(angle*Math.PI/180)} stroke="#fbbf24" strokeWidth="4" strokeLinecap="round" />
              ))}
            </svg>
          </div>
          <div className="relative">
            <p className="text-sm font-medium mb-0.5" style={{ color: "#fbbf24" }}>Welcome,</p>
            <h2 className="text-2xl font-bold text-white">{contract.clientName}</h2>
            <p className="text-slate-400 text-sm mt-1">Please review your solar installation contract and sign to proceed.</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 p-1 rounded-xl" style={{ background: "rgba(15,23,42,0.6)", border: "1px solid rgba(251,191,36,0.1)" }}>
          {[
            { id: "details" as const, label: "Project Details", icon: "📋" },
            { id: "contract" as const, label: "Contract & Sign", icon: "✍️" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2"
              style={{
                background: activeTab === tab.id ? "linear-gradient(135deg, #f97316, #fbbf24)" : "transparent",
                color: activeTab === tab.id ? "white" : "#94a3b8",
              }}
            >
              <span>{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Project Details Tab */}
        {activeTab === "details" && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* System Overview */}
              <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ background: "rgba(249,115,22,0.2)" }}>⚡</span>
                  System Overview
                </h3>
                <div className="space-y-0">
                  {[
                    { label: "System Size", value: contract.systemSize },
                    { label: "Panel Count", value: `${contract.panelCount} panels` },
                    { label: "Panel Warranty", value: `${contract.warrantyYears} years` },
                    { label: "Installation Date", value: contract.installationDate },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between items-center py-2.5 border-b" style={{ borderColor: "rgba(251,191,36,0.08)" }}>
                      <span className="text-slate-400 text-sm">{item.label}</span>
                      <span className="text-white text-sm font-medium">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Summary */}
              <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ background: "rgba(251,191,36,0.2)" }}>💰</span>
                  Financial Summary
                </h3>
                <div className="space-y-0">
                  {[
                    { label: "Total System Cost", value: contract.totalCost },
                    { label: "Monthly Payment", value: contract.monthlyPayment },
                    { label: "Federal Tax Credit (30%)", value: "Eligible" },
                    { label: "Net Metering", value: "Included" },
                  ].map((item) => (
                    <div key={item.label} className="flex justify-between items-center py-2.5 border-b" style={{ borderColor: "rgba(251,191,36,0.08)" }}>
                      <span className="text-slate-400 text-sm">{item.label}</span>
                      <span className="text-sm font-medium" style={{ color: "#fbbf24" }}>{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Installation Address */}
            <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ background: "rgba(59,130,246,0.2)" }}>📍</span>
                Installation Address
              </h3>
              <p className="text-slate-300">{contract.address}</p>
            </div>

            {/* Attachments */}
            {contract.attachments && contract.attachments.length > 0 && (
              <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ background: "rgba(168,85,247,0.2)" }}>📎</span>
                  Supporting Documents
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "1px solid rgba(251,191,36,0.2)" }}>
                    {contract.attachments.length}
                  </span>
                </h3>
                <AttachmentList attachments={contract.attachments} />
              </div>
            )}

            {/* Benefits */}
            <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ background: "rgba(34,197,94,0.2)" }}>🌱</span>
                Your Solar Benefits
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { icon: "☀️", title: "Clean Energy", desc: "Powered by the sun, 24/7 monitoring" },
                  { icon: "💵", title: "Savings", desc: "Reduce monthly utility bills significantly" },
                  { icon: "🏠", title: "Home Value", desc: "Increase property value by up to 4%" },
                ].map((benefit) => (
                  <div key={benefit.title} className="text-center p-3 rounded-lg" style={{ background: "rgba(255,255,255,0.03)" }}>
                    <div className="text-2xl mb-1">{benefit.icon}</div>
                    <p className="text-white text-sm font-medium">{benefit.title}</p>
                    <p className="text-slate-500 text-xs mt-0.5">{benefit.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setActiveTab("contract")}
                className="px-6 py-3 rounded-xl font-semibold text-white flex items-center gap-2 transition-all"
                style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: "0 4px 20px rgba(249,115,22,0.3)" }}
              >
                Review & Sign Contract
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </button>
            </div>
          </div>
        )}

        {/* Contract Tab */}
        {activeTab === "contract" && (
          <div className="space-y-6">
            {/* Contract Document */}
            <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(251,191,36,0.2)" }}>
              <div className="px-5 py-4 flex items-center justify-between" style={{ background: "rgba(249,115,22,0.1)", borderBottom: "1px solid rgba(251,191,36,0.15)" }}>
                <div className="flex items-center gap-3">
                  <svg className="w-5 h-5" style={{ color: "#fbbf24" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <span className="text-white font-semibold">Solar Installation Agreement</span>
                </div>
                <span className="text-xs px-2 py-1 rounded-full" style={{ background: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "1px solid rgba(251,191,36,0.2)" }}>
                  {contract.projectNumber}
                </span>
              </div>
              <div
                className="p-6 max-h-96 overflow-y-auto text-sm leading-relaxed"
                style={{ background: "rgba(15,23,42,0.9)", color: "#cbd5e1" }}
              >
                <pre className="whitespace-pre-wrap font-sans">{contract.contractText}</pre>
              </div>
            </div>

            {/* Attachments */}
            {contract.attachments && contract.attachments.length > 0 && (
              <div className="rounded-xl p-6" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.2)" }}>
                <h3 className="text-white font-semibold text-lg mb-1 flex items-center gap-2">
                  <svg className="w-5 h-5" style={{ color: "#fbbf24" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                  </svg>
                  Supporting Documents
                  <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "1px solid rgba(251,191,36,0.2)" }}>
                    {contract.attachments.length}
                  </span>
                </h3>
                <p className="text-slate-400 text-sm mb-4">Review the attached documents shared by your installer.</p>
                <AttachmentList attachments={contract.attachments} />
              </div>
            )}

            {/* Signing Section */}
            <div className="rounded-xl p-6" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.2)" }}>
              <h3 className="text-white font-semibold text-lg mb-1">Sign Your Contract</h3>
              <p className="text-slate-400 text-sm mb-5">Draw your signature in the box below using your mouse or finger on touch devices.</p>

              {/* Signature Canvas */}
              <div
                className="mb-2 rounded-xl overflow-hidden"
                style={{
                  border: sigError ? "2px solid rgba(239,68,68,0.5)" : "2px solid rgba(251,191,36,0.3)",
                }}
              >
                <SignatureBox onSigned={handleSigned} padRef={sigPadRef} />
              </div>
              {sigError && (
                <p className="mt-1 mb-2 text-red-400 text-sm flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  {sigError}
                </p>
              )}

              <div className="flex justify-between items-center mb-6">
                <p className="text-xs text-slate-500">Client: <span className="text-slate-300">{contract.clientName}</span></p>
                <button
                  onClick={clearSignature}
                  className="text-sm flex items-center gap-1 transition-colors"
                  style={{ color: "#94a3b8" }}
                  onMouseEnter={(e) => { (e.currentTarget).style.color = "#f87171"; }}
                  onMouseLeave={(e) => { (e.currentTarget).style.color = "#94a3b8"; }}
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  Clear Signature
                </button>
              </div>

              {/* Agreement Checkbox */}
              <div
                className="flex gap-3 p-4 rounded-xl mb-2 cursor-pointer select-none"
                style={{
                  background: agreed ? "rgba(34,197,94,0.08)" : "rgba(255,255,255,0.03)",
                  border: `1px solid ${agreed ? "rgba(34,197,94,0.3)" : agreementError ? "rgba(239,68,68,0.3)" : "rgba(255,255,255,0.08)"}`,
                }}
                onClick={() => { setAgreed(!agreed); if (!agreed) setAgreementError(""); }}
              >
                <div
                  className="w-5 h-5 rounded flex-shrink-0 flex items-center justify-center mt-0.5 transition-all"
                  style={{
                    background: agreed ? "#22c55e" : "rgba(30,41,59,0.8)",
                    border: `2px solid ${agreed ? "#22c55e" : "rgba(251,191,36,0.3)"}`,
                  }}
                >
                  {agreed && (
                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <p className="text-sm text-slate-300">
                  I, <strong className="text-white">{contract.clientName}</strong>, have read and understand all terms and conditions of this Solar Energy System Installation Agreement and agree to be legally bound by its terms.
                </p>
              </div>
              {agreementError && (
                <p className="mt-1 mb-4 text-red-400 text-sm flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  {agreementError}
                </p>
              )}

              {/* Date */}
              <div className="flex items-center gap-2 my-5 p-3 rounded-lg" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <svg className="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <span className="text-slate-400 text-sm">Signing date: </span>
                <span className="text-white text-sm font-medium">{signedDate}</span>
              </div>

              {/* Submit Button */}
              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="w-full py-4 rounded-xl font-bold text-white text-lg transition-all flex items-center justify-center gap-3"
                style={{
                  background: submitting ? "rgba(251,191,36,0.4)" : "linear-gradient(135deg, #f97316, #fbbf24)",
                  boxShadow: submitting ? "none" : "0 4px 30px rgba(249,115,22,0.4)",
                }}
              >
                {submitting ? (
                  <>
                    <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Submitting Contract...
                  </>
                ) : (
                  <>
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Submit Signed Contract
                  </>
                )}
              </button>

              <p className="text-center text-xs text-slate-500 mt-3">
                🔒 Your signature is encrypted and securely stored. This document is legally binding.
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

interface SuccessPageProps {
  contract: Contract;
  sigDataUrl: string | null;
  signedDate: string;
  onLogout: () => void;
}

function SuccessPage({ contract, sigDataUrl, signedDate, onLogout }: SuccessPageProps) {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12" style={{ background: "linear-gradient(160deg, #0f172a 0%, #1e293b 50%, #0c1a2e 100%)" }}>
      <div className="w-full max-w-2xl">
        {/* Success Icon */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <div
              className="absolute inset-0 rounded-full blur-2xl opacity-50"
              style={{ background: "radial-gradient(circle, rgba(34,197,94,0.5) 0%, transparent 70%)" }}
            />
            <div
              className="relative w-24 h-24 rounded-full mx-auto flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #16a34a, #22c55e)", boxShadow: "0 0 40px rgba(34,197,94,0.4)" }}
            >
              <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mt-6">Contract Signed! 🎉</h1>
          <p className="text-slate-400 mt-2">Your solar installation agreement has been successfully submitted.</p>
        </div>

        {/* Confirmation Card */}
        <div className="rounded-2xl p-6 mb-6" style={{ background: "rgba(15,23,42,0.9)", border: "1px solid rgba(34,197,94,0.2)", boxShadow: "0 0 40px rgba(34,197,94,0.08)" }}>
          <h2 className="text-white font-semibold text-lg mb-4 flex items-center gap-2">
            <svg className="w-5 h-5" style={{ color: "#22c55e" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Confirmation Details
          </h2>
          <div className="space-y-0">
            {[
              { label: "Client", value: contract.clientName },
              { label: "Project Number", value: contract.projectNumber },
              { label: "System Size", value: contract.systemSize },
              { label: "Installation Address", value: contract.address },
              { label: "Date Signed", value: signedDate },
              { label: "Status", value: "✅ Signed & Submitted" },
            ].map((item) => (
              <div key={item.label} className="flex flex-col sm:flex-row sm:justify-between sm:items-center py-2.5 border-b" style={{ borderColor: "rgba(34,197,94,0.08)" }}>
                <span className="text-slate-400 text-sm">{item.label}</span>
                <span className="text-white text-sm font-medium">{item.value}</span>
              </div>
            ))}
          </div>

          {sigDataUrl && (
            <div className="mt-5">
              <p className="text-slate-400 text-sm mb-2">Your Signature:</p>
              <div className="rounded-xl overflow-hidden p-3 bg-white">
                <img src={sigDataUrl} alt="Client Signature" className="max-h-20 mx-auto" />
              </div>
            </div>
          )}
        </div>

        {/* Next Steps */}
        <div className="rounded-2xl p-6 mb-6" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
          <h3 className="text-white font-semibold mb-4">What Happens Next?</h3>
          <div className="space-y-4">
            {[
              { step: "1", title: "Permit Processing", desc: "Our team will submit all required building and electrical permits (2–4 weeks)", icon: "📋" },
              { step: "2", title: "Equipment Delivery", desc: "Your solar panels and equipment will be ordered and delivered to the site", icon: "📦" },
              { step: "3", title: "Installation Day", desc: `Your system will be installed on ${contract.installationDate}`, icon: "🔧" },
              { step: "4", title: "Utility Interconnection", desc: "We'll coordinate with your utility for net metering approval and activation", icon: "⚡" },
            ].map((item) => (
              <div key={item.step} className="flex gap-4 items-start">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", color: "white" }}
                >
                  {item.step}
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{item.icon} {item.title}</p>
                  <p className="text-slate-400 text-xs mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => window.print()}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-sm"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#cbd5e1" }}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Print Confirmation
          </button>
          <button
            onClick={onLogout}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all text-sm text-white"
            style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: "0 4px 20px rgba(249,115,22,0.3)" }}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            Back to Home
          </button>
        </div>

        <p className="text-center text-slate-600 text-xs mt-6">
          A confirmation email will be sent to you shortly · © 2024 EzSign
        </p>
      </div>
    </div>
  );
}
