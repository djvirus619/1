import { useRef, useState } from "react";
import { Attachment } from "../data/contracts";

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(2) + " MB";
}

function getFileIcon(type: string): string {
  if (type.startsWith("image/")) return "🖼️";
  if (type === "application/pdf") return "📕";
  if (type.includes("word") || type.includes("document")) return "📝";
  if (type.includes("sheet") || type.includes("excel")) return "📊";
  if (type.includes("zip") || type.includes("rar") || type.includes("compressed")) return "🗜️";
  if (type.startsWith("text/")) return "📄";
  if (type.startsWith("video/")) return "🎬";
  if (type.startsWith("audio/")) return "🎵";
  return "📎";
}

interface AttachmentUploaderProps {
  attachments: Attachment[];
  onChange: (attachments: Attachment[]) => void;
}

export function AttachmentUploader({ attachments, onChange }: AttachmentUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState("");

  const readFile = (file: File): Promise<Attachment> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        resolve({
          id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
          name: file.name,
          type: file.type || "application/octet-stream",
          size: file.size,
          dataUrl: reader.result as string,
        });
      };
      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.readAsDataURL(file);
    });
  };

  const addFiles = async (files: FileList | File[]) => {
    setError("");
    const fileArr = Array.from(files);
    const tooBig = fileArr.find((f) => f.size > MAX_FILE_SIZE);
    if (tooBig) {
      setError(`"${tooBig.name}" exceeds the 10MB size limit.`);
      return;
    }
    try {
      const newAttachments = await Promise.all(fileArr.map(readFile));
      onChange([...attachments, ...newAttachments]);
    } catch {
      setError("Failed to upload one or more files.");
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      addFiles(e.target.files);
      e.target.value = ""; // reset so same file can be re-selected
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files.length > 0) {
      addFiles(e.dataTransfer.files);
    }
  };

  const removeAttachment = (id: string) => {
    onChange(attachments.filter((a) => a.id !== id));
  };

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        multiple
        onChange={handleFileInput}
        className="hidden"
        accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt,.zip"
      />

      {/* Dropzone */}
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className="rounded-xl p-6 cursor-pointer text-center transition-all"
        style={{
          background: isDragging ? "rgba(251,191,36,0.1)" : "rgba(30,41,59,0.5)",
          border: `2px dashed ${isDragging ? "rgba(251,191,36,0.6)" : "rgba(251,191,36,0.25)"}`,
        }}
      >
        <div className="flex flex-col items-center gap-2">
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center"
            style={{ background: "rgba(251,191,36,0.1)", border: "1px solid rgba(251,191,36,0.2)" }}
          >
            <svg className="w-6 h-6" style={{ color: "#fbbf24" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
          </div>
          <p className="text-white text-sm font-medium">
            {isDragging ? "Drop files here" : "Click to upload or drag and drop"}
          </p>
          <p className="text-slate-500 text-xs">
            Permits, plans, photos, datasheets · Max 10MB per file
          </p>
        </div>
      </div>

      {error && (
        <div className="mt-3 rounded-lg p-2.5 flex items-start gap-2" style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)" }}>
          <svg className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-red-400 text-xs">{error}</p>
        </div>
      )}

      {/* Uploaded files */}
      {attachments.length > 0 && (
        <div className="mt-4 space-y-2">
          <p className="text-xs text-slate-400 font-medium">
            {attachments.length} file{attachments.length !== 1 ? "s" : ""} attached
          </p>
          {attachments.map((att) => (
            <div
              key={att.id}
              className="flex items-center gap-3 p-3 rounded-lg"
              style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.1)" }}
            >
              {att.type.startsWith("image/") ? (
                <img src={att.dataUrl} alt={att.name} className="w-10 h-10 rounded object-cover flex-shrink-0" />
              ) : (
                <div
                  className="w-10 h-10 rounded flex items-center justify-center text-xl flex-shrink-0"
                  style={{ background: "rgba(251,191,36,0.1)" }}
                >
                  {getFileIcon(att.type)}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium truncate">{att.name}</p>
                <p className="text-xs text-slate-500">{formatBytes(att.size)}</p>
              </div>
              <button
                type="button"
                onClick={() => removeAttachment(att.id)}
                className="p-1.5 rounded-lg transition-colors flex-shrink-0"
                style={{ color: "#94a3b8" }}
                title="Remove"
                onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#ef4444"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(239,68,68,0.1)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface AttachmentListProps {
  attachments: Attachment[];
}

export function AttachmentList({ attachments }: AttachmentListProps) {
  if (!attachments || attachments.length === 0) {
    return (
      <p className="text-slate-500 text-sm italic">No attachments included.</p>
    );
  }

  const handleDownload = (att: Attachment) => {
    const link = document.createElement("a");
    link.href = att.dataUrl;
    link.download = att.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePreview = (att: Attachment) => {
    const win = window.open();
    if (win) {
      if (att.type.startsWith("image/")) {
        win.document.write(`<title>${att.name}</title><body style="margin:0;background:#0f172a;display:flex;align-items:center;justify-content:center;min-height:100vh;"><img src="${att.dataUrl}" style="max-width:100%;max-height:100vh;"/></body>`);
      } else if (att.type === "application/pdf") {
        win.document.write(`<title>${att.name}</title><body style="margin:0;"><iframe src="${att.dataUrl}" style="border:0;width:100vw;height:100vh;"></iframe></body>`);
      } else {
        handleDownload(att);
        win.close();
      }
    }
  };

  return (
    <div className="space-y-2">
      {attachments.map((att) => (
        <div
          key={att.id}
          className="flex items-center gap-3 p-3 rounded-lg transition-colors"
          style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.1)" }}
        >
          {att.type.startsWith("image/") ? (
            <img
              src={att.dataUrl}
              alt={att.name}
              className="w-12 h-12 rounded object-cover flex-shrink-0 cursor-pointer"
              onClick={() => handlePreview(att)}
            />
          ) : (
            <div
              className="w-12 h-12 rounded flex items-center justify-center text-2xl flex-shrink-0"
              style={{ background: "rgba(251,191,36,0.1)" }}
            >
              {getFileIcon(att.type)}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium truncate">{att.name}</p>
            <p className="text-xs text-slate-500">{formatBytes(att.size)}</p>
          </div>
          <div className="flex gap-1 flex-shrink-0">
            {(att.type.startsWith("image/") || att.type === "application/pdf") && (
              <button
                type="button"
                onClick={() => handlePreview(att)}
                className="p-1.5 rounded-lg transition-colors"
                style={{ color: "#94a3b8" }}
                title="Preview"
                onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#fbbf24"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(251,191,36,0.1)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </button>
            )}
            <button
              type="button"
              onClick={() => handleDownload(att)}
              className="p-1.5 rounded-lg transition-colors"
              style={{ color: "#94a3b8" }}
              title="Download"
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#22c55e"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(34,197,94,0.1)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
