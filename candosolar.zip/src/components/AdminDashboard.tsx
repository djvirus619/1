import { useState, useMemo } from "react";
import { Contract, Attachment, getContracts, addContract, deleteContract, generateContractFromForm } from "../data/contracts";
import { AttachmentUploader, AttachmentList } from "./Attachments";

interface AdminDashboardProps {
  onLogout: () => void;
}

type ViewMode = "list" | "create" | "detail";

const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "solarpass2024";

export function AdminLogin({ onLogin }: { onLogin: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    setTimeout(() => {
      if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        onLogin();
      } else {
        setError("Invalid admin credentials.");
      }
      setLoading(false);
    }, 600);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: "linear-gradient(160deg, #0f172a 0%, #1e293b 40%, #0c1a2e 100%)" }}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4">
            <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
              {[0,45,90,135,180,225,270,315].map((angle, i) => (
                <line key={i} x1="60" y1="60" x2={60+48*Math.cos(angle*Math.PI/180)} y2={60+48*Math.sin(angle*Math.PI/180)} stroke="url(#adminRay)" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
              ))}
              <circle cx="60" cy="60" r="22" fill="url(#adminSun)" />
              <path d="M45 60 L55 70 L75 45" stroke="white" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.9" />
              <defs>
                <radialGradient id="adminSun" cx="40%" cy="35%" r="60%">
                  <stop offset="0%" stopColor="#fde68a" />
                  <stop offset="60%" stopColor="#fbbf24" />
                  <stop offset="100%" stopColor="#f97316" />
                </radialGradient>
                <linearGradient id="adminRay" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#fbbf24" />
                  <stop offset="100%" stopColor="#f97316" stopOpacity="0.2" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-white">Admin Portal</h1>
          <p className="text-slate-400 text-sm mt-1">EzSign Management</p>
        </div>

        <div className="rounded-2xl p-6" style={{ background: "rgba(15,23,42,0.85)", backdropFilter: "blur(20px)", border: "1px solid rgba(251,191,36,0.2)", boxShadow: "0 0 40px rgba(251,191,36,0.08)" }}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                required
                className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 transition-all focus:outline-none"
                style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.2)" }}
                onFocus={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.6)"; e.target.style.boxShadow = "0 0 0 3px rgba(251,191,36,0.1)"; }}
                onBlur={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.2)"; e.target.style.boxShadow = "none"; }}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 transition-all focus:outline-none"
                style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.2)" }}
                onFocus={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.6)"; e.target.style.boxShadow = "0 0 0 3px rgba(251,191,36,0.1)"; }}
                onBlur={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.2)"; e.target.style.boxShadow = "none"; }}
              />
            </div>
            {error && (
              <div className="rounded-lg p-3 flex items-start gap-2" style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)" }}>
                <svg className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-red-400 text-sm">{error}</p>
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-white transition-all flex items-center justify-center gap-2"
              style={{ background: loading ? "rgba(251,191,36,0.4)" : "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: loading ? "none" : "0 4px 20px rgba(249,115,22,0.4)" }}
            >
              {loading ? (
                <>
                  <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Verifying...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                  </svg>
                  Admin Login
                </>
              )}
            </button>
          </form>

          <div className="mt-4 pt-4 border-t" style={{ borderColor: "rgba(251,191,36,0.1)" }}>
            <p className="text-center text-xs text-slate-500">Demo: admin / solarpass2024</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [contracts, setContracts] = useState<Contract[]>(getContracts());
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "signed" | "cancelled">("all");
  const [showSendModal, setShowSendModal] = useState(false);
  const [sendContract, setSendContract] = useState<Contract | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const filteredContracts = useMemo(() => {
    return contracts.filter((c) => {
      const matchesSearch =
        c.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.projectNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.address.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === "all" || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [contracts, searchQuery, statusFilter]);

  const stats = useMemo(() => ({
    total: contracts.length,
    pending: contracts.filter((c) => c.status === "pending").length,
    signed: contracts.filter((c) => c.status === "signed").length,
    cancelled: contracts.filter((c) => c.status === "cancelled").length,
  }), [contracts]);

  const handleDelete = (projectNumber: string) => {
    if (window.confirm("Are you sure you want to delete this contract?")) {
      deleteContract(projectNumber);
      setContracts(getContracts());
    }
  };

  const handleCreate = (data: Parameters<typeof generateContractFromForm>[0]) => {
    const newContract = generateContractFromForm(data);
    addContract(newContract);
    setContracts(getContracts());
    setShowSendModal(true);
    setSendContract(newContract);
    setViewMode("list");
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const refreshContracts = () => {
    setContracts(getContracts());
  };

  const handleSendEmail = () => {
    if (!email) return;
    setSendingEmail(true);
    setTimeout(() => {
      setSendingEmail(false);
      setEmailSent(true);
      setTimeout(() => setEmailSent(false), 3000);
    }, 1500);
  };

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(160deg, #0f172a 0%, #1e293b 50%, #0c1a2e 100%)" }}>
      {/* Header */}
      <header className="sticky top-0 z-50 border-b" style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(20px)", borderColor: "rgba(251,191,36,0.15)" }}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9">
              <svg viewBox="0 0 120 120" className="w-full h-full" fill="none">
                {[0,45,90,135,180,225,270,315].map((angle, i) => (
                  <line key={i} x1="60" y1="60" x2={60+45*Math.cos(angle*Math.PI/180)} y2={60+45*Math.sin(angle*Math.PI/180)} stroke="url(#dashRay)" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
                ))}
                <circle cx="60" cy="60" r="20" fill="url(#dashSun)" />
                <defs>
                  <radialGradient id="dashSun" cx="40%" cy="35%" r="60%">
                    <stop offset="0%" stopColor="#fde68a" />
                    <stop offset="60%" stopColor="#fbbf24" />
                    <stop offset="100%" stopColor="#f97316" />
                  </radialGradient>
                  <linearGradient id="dashRay" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#fbbf24" />
                    <stop offset="100%" stopColor="#f97316" stopOpacity="0.2" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <div>
              <h1 className="text-white font-bold text-lg leading-tight">EzSign</h1>
              <p className="text-xs" style={{ color: "#fbbf24" }}>Admin Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={refreshContracts}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all"
              style={{ background: "rgba(251,191,36,0.1)", border: "1px solid rgba(251,191,36,0.2)", color: "#fbbf24" }}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all"
              style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", color: "#f87171" }}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {viewMode === "list" && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 mb-5 max-w-3xl">
              {[
                { label: "Total Contracts", value: stats.total, color: "#3b82f6", icon: "📄" },
                { label: "Pending", value: stats.pending, color: "#fbbf24", icon: "⏳" },
                { label: "Signed", value: stats.signed, color: "#22c55e", icon: "✅" },
                { label: "Cancelled", value: stats.cancelled, color: "#ef4444", icon: "❌" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-lg px-3 py-2.5" style={{ background: "rgba(15,23,42,0.8)", border: `1px solid ${stat.color}30` }}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-base">{stat.icon}</span>
                    <span className="text-lg font-bold" style={{ color: stat.color }}>{stat.value}</span>
                  </div>
                  <p className="text-slate-400 text-xs">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by client, project number, or address..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none"
                  style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}
                  onFocus={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.4)"; }}
                  onBlur={(e) => { e.target.style.borderColor = "rgba(251,191,36,0.15)"; }}
                />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
                className="px-4 py-2.5 rounded-xl text-sm text-white transition-all focus:outline-none"
                style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}
              >
                <option value="all" style={{ background: "#0f172a" }}>All Status</option>
                <option value="pending" style={{ background: "#0f172a" }}>Pending</option>
                <option value="signed" style={{ background: "#0f172a" }}>Signed</option>
                <option value="cancelled" style={{ background: "#0f172a" }}>Cancelled</option>
              </select>
              <button
                onClick={() => setViewMode("create")}
                className="px-5 py-2.5 rounded-xl font-semibold text-white text-sm transition-all flex items-center justify-center gap-2 whitespace-nowrap"
                style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: "0 4px 20px rgba(249,115,22,0.3)" }}
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                New Contract
              </button>
            </div>

            {/* Table */}
            <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(251,191,36,0.15)" }}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: "rgba(249,115,22,0.08)" }}>
                      {["Project #", "Client", "System", "Status", "Actions"].map((h) => (
                        <th key={h} className="text-left px-4 py-3 font-semibold" style={{ color: "#fbbf24" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredContracts.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-4 py-12 text-center text-slate-500">
                          <div className="text-4xl mb-2">🔍</div>
                          <p>No contracts found matching your search.</p>
                        </td>
                      </tr>
                    ) : (
                      filteredContracts.map((c) => (
                        <tr
                          key={c.projectNumber}
                          className="transition-colors"
                          style={{ borderTop: "1px solid rgba(251,191,36,0.06)" }}
                          onMouseEnter={(e) => { (e.currentTarget as HTMLTableRowElement).style.background = "rgba(251,191,36,0.04)"; }}
                          onMouseLeave={(e) => { (e.currentTarget as HTMLTableRowElement).style.background = "transparent"; }}
                        >
                          <td className="px-4 py-3">
                            <span className="font-mono font-semibold text-white">{c.projectNumber}</span>
                            <div className="text-xs text-slate-500 mt-0.5">Code: {c.uniqueCode}</div>
                          </td>
                          <td className="px-4 py-3">
                            <p className="text-white font-medium">{c.clientName}</p>
                            <p className="text-xs text-slate-500 truncate max-w-[200px]">{c.address}</p>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <p className="text-white">{c.systemSize}</p>
                              {c.attachments && c.attachments.length > 0 && (
                                <span className="inline-flex items-center gap-0.5 text-xs px-1.5 py-0.5 rounded" style={{ background: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "1px solid rgba(251,191,36,0.2)" }} title={`${c.attachments.length} attachment(s)`}>
                                  📎 {c.attachments.length}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-500">{c.panelCount} panels · {c.totalCost}</p>
                          </td>
                          <td className="px-4 py-3">
                            <StatusBadge status={c.status} />
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => { setSelectedContract(c); setViewMode("detail"); }}
                                className="p-1.5 rounded-lg transition-colors"
                                style={{ color: "#94a3b8" }}
                                title="View Details"
                                onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#fbbf24"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(251,191,36,0.1)"; }}
                                onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
                              >
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                </svg>
                              </button>
                              <button
                                onClick={() => { setSendContract(c); setEmail(""); setEmailSent(false); setShowSendModal(true); }}
                                className="p-1.5 rounded-lg transition-colors"
                                style={{ color: "#94a3b8" }}
                                title="Send to Client"
                                onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#22c55e"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(34,197,94,0.1)"; }}
                                onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
                              >
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                </svg>
                              </button>
                              <button
                                onClick={() => handleDelete(c.projectNumber)}
                                className="p-1.5 rounded-lg transition-colors"
                                style={{ color: "#94a3b8" }}
                                title="Delete"
                                onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#ef4444"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(239,68,68,0.1)"; }}
                                onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
                              >
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {viewMode === "create" && (
          <CreateContractForm
            onCancel={() => setViewMode("list")}
            onCreate={handleCreate}
          />
        )}

        {viewMode === "detail" && selectedContract && (
          <ContractDetailView
            contract={selectedContract}
            onBack={() => { setViewMode("list"); setSelectedContract(null); }}
          />
        )}
      </main>

      {/* Send Modal */}
      {showSendModal && sendContract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}>
          <div className="w-full max-w-md rounded-2xl p-6 relative" style={{ background: "rgba(15,23,42,0.95)", border: "1px solid rgba(251,191,36,0.3)", boxShadow: "0 0 60px rgba(251,191,36,0.15)" }}>
            <button
              onClick={() => setShowSendModal(false)}
              className="absolute top-3 right-3 p-1 rounded-lg transition-colors"
              style={{ color: "#94a3b8" }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#f87171"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; }}
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="text-center mb-6">
              <div className="w-14 h-14 rounded-full mx-auto flex items-center justify-center mb-3" style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)" }}>
                <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-white">Contract Ready to Send</h3>
              <p className="text-slate-400 text-sm mt-1">Share these credentials with {sendContract.clientName}</p>
            </div>

            <div className="space-y-3 mb-6">
              <CopyField
                label="Project Number"
                value={sendContract.projectNumber}
                copied={copiedField === "project"}
                onCopy={() => copyToClipboard(sendContract.projectNumber, "project")}
              />
              <CopyField
                label="Unique Access Code"
                value={sendContract.uniqueCode}
                copied={copiedField === "code"}
                onCopy={() => copyToClipboard(sendContract.uniqueCode, "code")}
              />
              <div className="pt-2">
                <label className="block text-xs text-slate-500 mb-1">Email Credentials to Client</label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="client@email.com"
                    className="flex-1 px-3 py-2 rounded-lg text-sm text-white placeholder-slate-600 focus:outline-none"
                    style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}
                  />
                  <button
                    onClick={handleSendEmail}
                    disabled={sendingEmail || !email}
                    className="px-4 py-2 rounded-lg text-xs font-semibold text-white transition-all"
                    style={{ background: sendingEmail ? "rgba(251,191,36,0.4)" : "linear-gradient(135deg, #f97316, #fbbf24)" }}
                  >
                    {sendingEmail ? "Sending..." : "Send"}
                  </button>
                </div>
                {emailSent && <p className="text-green-400 text-xs mt-1">Email sent successfully!</p>}
              </div>
            </div>

            <button
              onClick={() => { setShowSendModal(false); setEmail(""); setEmailSent(false); }}
              className="w-full py-3 rounded-xl font-semibold text-white transition-all"
              style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: "0 4px 20px rgba(249,115,22,0.3)" }}
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: Contract["status"] }) {
  const config = {
    pending: { bg: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "rgba(251,191,36,0.2)", label: "Pending" },
    signed: { bg: "rgba(34,197,94,0.1)", color: "#22c55e", border: "rgba(34,197,94,0.2)", label: "Signed" },
    cancelled: { bg: "rgba(239,68,68,0.1)", color: "#ef4444", border: "rgba(239,68,68,0.2)", label: "Cancelled" },
  };
  const c = config[status];
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium" style={{ background: c.bg, color: c.color, border: `1px solid ${c.border}` }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: c.color }} />
      {c.label}
    </span>
  );
}

function CopyField({ label, value, copied, onCopy }: { label: string; value: string; copied: boolean; onCopy: () => void }) {
  return (
    <div className="rounded-xl p-3" style={{ background: "rgba(30,41,59,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
      <p className="text-xs text-slate-500 mb-1">{label}</p>
      <div className="flex items-center gap-2">
        <code className="flex-1 text-white font-mono text-sm bg-transparent">{value}</code>
        <button
          onClick={onCopy}
          className="p-1.5 rounded-lg transition-all text-xs font-medium flex items-center gap-1"
          style={{
            background: copied ? "rgba(34,197,94,0.15)" : "rgba(251,191,36,0.1)",
            color: copied ? "#22c55e" : "#fbbf24",
            border: `1px solid ${copied ? "rgba(34,197,94,0.3)" : "rgba(251,191,36,0.2)"}`,
          }}
        >
          {copied ? (
            <>
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Copied
            </>
          ) : (
            <>
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              Copy
            </>
          )}
        </button>
      </div>
    </div>
  );
}

function CreateContractForm({ onCancel, onCreate }: { onCancel: () => void; onCreate: (data: Parameters<typeof generateContractFromForm>[0]) => void }) {
  const [form, setForm] = useState({
    clientName: "",
    address: "",
    systemSize: "",
    panelCount: 0,
    totalCost: "",
    monthlyPayment: "",
    installationDate: "",
    warrantyYears: 25,
    state: "",
  });
  const [attachments, setAttachments] = useState<Attachment[]>([]);

  const handleChange = (field: string, value: string | number) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreate({ ...form, attachments } as Parameters<typeof generateContractFromForm>[0]);
  };

  const inputStyle = {
    background: "rgba(30,41,59,0.8)",
    border: "1px solid rgba(251,191,36,0.15)",
  };

  const inputFocus = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
    e.target.style.borderColor = "rgba(251,191,36,0.4)";
    e.target.style.boxShadow = "0 0 0 3px rgba(251,191,36,0.08)";
  };

  const inputBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
    e.target.style.borderColor = "rgba(251,191,36,0.15)";
    e.target.style.boxShadow = "none";
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onCancel}
          className="p-2 rounded-lg transition-colors"
          style={{ color: "#94a3b8" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#fbbf24"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(251,191,36,0.1)"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
        </button>
        <h2 className="text-xl font-bold text-white">Create New Contract</h2>
      </div>

      <form onSubmit={handleSubmit} className="rounded-xl p-6" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Client Name</label>
            <input required type="text" value={form.clientName} onChange={(e) => handleChange("clientName", e.target.value)} placeholder="e.g. John & Sarah Mitchell" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Installation Address</label>
            <input required type="text" value={form.address} onChange={(e) => handleChange("address", e.target.value)} placeholder="e.g. 1425 Sunridge Drive, Austin, TX 78701" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>System Size</label>
            <input required type="text" value={form.systemSize} onChange={(e) => handleChange("systemSize", e.target.value)} placeholder="e.g. 8.5 kW" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Panel Count</label>
            <input required type="number" min={1} value={form.panelCount || ""} onChange={(e) => handleChange("panelCount", parseInt(e.target.value) || 0)} placeholder="e.g. 22" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Total Cost</label>
            <input required type="text" value={form.totalCost} onChange={(e) => handleChange("totalCost", e.target.value)} placeholder="e.g. $28,500" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Monthly Payment</label>
            <input required type="text" value={form.monthlyPayment} onChange={(e) => handleChange("monthlyPayment", e.target.value)} placeholder="e.g. $189/mo" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Installation Date</label>
            <input required type="text" value={form.installationDate} onChange={(e) => handleChange("installationDate", e.target.value)} placeholder="e.g. February 15, 2025" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>State</label>
            <input required type="text" value={form.state} onChange={(e) => handleChange("state", e.target.value)} placeholder="e.g. Texas" className="w-full px-4 py-3 rounded-xl text-white placeholder-slate-500 text-sm transition-all focus:outline-none" style={inputStyle} onFocus={inputFocus} onBlur={inputBlur} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: "#fbbf24" }}>Warranty Years</label>
            <select value={form.warrantyYears} onChange={(e) => handleChange("warrantyYears", parseInt(e.target.value))} className="w-full px-4 py-3 rounded-xl text-white text-sm transition-all focus:outline-none" style={{ ...inputStyle, appearance: "auto" }} onFocus={inputFocus} onBlur={inputBlur}>
              <option value={20} style={{ background: "#0f172a" }}>20 Years</option>
              <option value={25} style={{ background: "#0f172a" }}>25 Years</option>
              <option value={30} style={{ background: "#0f172a" }}>30 Years</option>
            </select>
          </div>
        </div>

        {/* Attachments Section */}
        <div className="mt-6 pt-6 border-t" style={{ borderColor: "rgba(251,191,36,0.1)" }}>
          <div className="flex items-center justify-between mb-3">
            <div>
              <label className="block text-sm font-semibold" style={{ color: "#fbbf24" }}>
                Attachments
              </label>
              <p className="text-xs text-slate-500 mt-0.5">Upload permits, plans, datasheets or photos to share with the client</p>
            </div>
            {attachments.length > 0 && (
              <span className="text-xs px-2 py-1 rounded-full" style={{ background: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "1px solid rgba(251,191,36,0.2)" }}>
                {attachments.length} file{attachments.length !== 1 ? "s" : ""}
              </span>
            )}
          </div>
          <AttachmentUploader attachments={attachments} onChange={setAttachments} />
        </div>

        <div className="flex gap-3 mt-6">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-3 rounded-xl font-semibold text-sm transition-all"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#94a3b8" }}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 py-3 rounded-xl font-semibold text-white text-sm transition-all"
            style={{ background: "linear-gradient(135deg, #f97316, #fbbf24)", boxShadow: "0 4px 20px rgba(249,115,22,0.3)" }}
          >
            Create & Generate Credentials
          </button>
        </div>
      </form>
    </div>
  );
}

function ContractDetailView({ contract, onBack }: { contract: Contract; onBack: () => void }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onBack}
          className="p-2 rounded-lg transition-colors"
          style={{ color: "#94a3b8" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#fbbf24"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(251,191,36,0.1)"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "#94a3b8"; (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
        </button>
        <h2 className="text-xl font-bold text-white">Contract Details</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
          <h3 className="text-white font-semibold mb-4">Client Information</h3>
          <div className="space-y-2">
            {[
              { label: "Name", value: contract.clientName },
              { label: "Address", value: contract.address },
              { label: "Project #", value: contract.projectNumber },
              { label: "Access Code", value: contract.uniqueCode },
            ].map((item) => (
              <div key={item.label} className="flex justify-between py-1.5 border-b" style={{ borderColor: "rgba(251,191,36,0.06)" }}>
                <span className="text-slate-400 text-sm">{item.label}</span>
                <span className="text-white text-sm font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
          <h3 className="text-white font-semibold mb-4">System Details</h3>
          <div className="space-y-2">
            {[
              { label: "System Size", value: contract.systemSize },
              { label: "Panels", value: `${contract.panelCount}` },
              { label: "Total Cost", value: contract.totalCost },
              { label: "Monthly", value: contract.monthlyPayment },
              { label: "Install Date", value: contract.installationDate },
              { label: "Warranty", value: `${contract.warrantyYears} years` },
              { label: "Status", value: <StatusBadge status={contract.status} /> },
            ].map((item) => (
              <div key={item.label} className="flex justify-between items-center py-1.5 border-b" style={{ borderColor: "rgba(251,191,36,0.06)" }}>
                <span className="text-slate-400 text-sm">{item.label}</span>
                <span className="text-white text-sm font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="rounded-xl overflow-hidden mb-6" style={{ border: "1px solid rgba(251,191,36,0.15)" }}>
        <div className="px-5 py-3" style={{ background: "rgba(249,115,22,0.08)", borderBottom: "1px solid rgba(251,191,36,0.1)" }}>
          <span className="text-white font-semibold text-sm">Contract Document</span>
        </div>
        <div className="p-5 max-h-96 overflow-y-auto text-sm leading-relaxed" style={{ background: "rgba(15,23,42,0.9)", color: "#cbd5e1" }}>
          <pre className="whitespace-pre-wrap font-sans">{contract.contractText}</pre>
        </div>
      </div>

      {/* Attachments */}
      <div className="rounded-xl p-5" style={{ background: "rgba(15,23,42,0.8)", border: "1px solid rgba(251,191,36,0.15)" }}>
        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
          <svg className="w-5 h-5" style={{ color: "#fbbf24" }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
          </svg>
          Attachments
          {contract.attachments && contract.attachments.length > 0 && (
            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(251,191,36,0.1)", color: "#fbbf24", border: "1px solid rgba(251,191,36,0.2)" }}>
              {contract.attachments.length}
            </span>
          )}
        </h3>
        <AttachmentList attachments={contract.attachments || []} />
      </div>
    </div>
  );
}
