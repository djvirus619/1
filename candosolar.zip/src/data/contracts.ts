export interface Attachment {
  id: string;
  name: string;
  type: string;
  size: number;
  dataUrl: string; // base64 data URL
}

export interface Contract {
  projectNumber: string;
  uniqueCode: string;
  clientName: string;
  address: string;
  systemSize: string;
  panelCount: number;
  totalCost: string;
  monthlyPayment: string;
  installationDate: string;
  warrantyYears: number;
  contractText: string;
  status: "pending" | "signed" | "cancelled";
  signedDate?: string;
  attachments?: Attachment[];
}

let _contracts: Contract[] = [
  {
    projectNumber: "SOL-2024-001",
    uniqueCode: "SUNRAY7",
    clientName: "John & Sarah Mitchell",
    address: "1425 Sunridge Drive, Austin, TX 78701",
    systemSize: "8.5 kW",
    panelCount: 22,
    totalCost: "$28,500",
    monthlyPayment: "$189/mo",
    installationDate: "February 15, 2025",
    warrantyYears: 25,
    status: "pending",
    contractText: generateContractText("John & Sarah Mitchell", "Austin, TX", 22, "8.5 kW", "$28,500", "$189/mo", "February 15, 2025", "Texas"),
  },
  {
    projectNumber: "SOL-2024-002",
    uniqueCode: "BRIGHT9",
    clientName: "Robert & Linda Chen",
    address: "8820 Willow Creek Blvd, San Diego, CA 92101",
    systemSize: "12.0 kW",
    panelCount: 30,
    totalCost: "$38,750",
    monthlyPayment: "$257/mo",
    installationDate: "March 3, 2025",
    warrantyYears: 25,
    status: "pending",
    contractText: generateContractText("Robert & Linda Chen", "San Diego, CA", 30, "12.0 kW", "$38,750", "$257/mo", "March 3, 2025", "California"),
  },
  {
    projectNumber: "SOL-2024-003",
    uniqueCode: "PHOTON3",
    clientName: "Marcus Johnson",
    address: "3301 Desert Palm Ave, Phoenix, AZ 85001",
    systemSize: "6.2 kW",
    panelCount: 16,
    totalCost: "$21,200",
    monthlyPayment: "$141/mo",
    installationDate: "January 28, 2025",
    warrantyYears: 25,
    status: "pending",
    contractText: generateContractText("Marcus Johnson", "Phoenix, AZ", 16, "6.2 kW", "$21,200", "$141/mo", "January 28, 2025", "Arizona"),
  },
];

function generateContractText(
  _clientName: string,
  _location: string,
  panelCount: number,
  systemSize: string,
  totalCost: string,
  monthlyPayment: string,
  _installationDate: string,
  state: string
): string {
  return `SOLAR ENERGY SYSTEM INSTALLATION AGREEMENT

This Solar Energy System Installation Agreement ("Agreement") is entered into as of the date of signing between EzSign ("Company") and the client identified below ("Client").

1. SCOPE OF WORK
The Company agrees to design, procure, and install a residential solar photovoltaic (PV) system at the Client's property. The system shall consist of ${panelCount} high-efficiency solar panels with a combined capacity of ${systemSize}, along with all necessary inverters, mounting hardware, wiring, and monitoring equipment.

2. INSTALLATION TIMELINE
The Company shall complete installation by the agreed Installation Date. Delays caused by weather, permitting, or utility interconnection timelines shall not constitute a breach of this Agreement.

3. PAYMENT TERMS
Total system cost: ${totalCost}. Client agrees to the financing terms of ${monthlyPayment} for the agreed loan term. A deposit may be required prior to installation.

4. WARRANTIES
• Solar Panels: 25-year performance warranty guaranteeing at least 80% output
• Inverter: 10-year manufacturer warranty
• Workmanship: 5-year warranty on all labor and installation

5. PERMITS & APPROVALS
The Company will handle all necessary building permits, electrical permits, and utility interconnection applications on behalf of the Client.

6. SYSTEM MONITORING
The Client will receive access to a real-time monitoring portal to track energy production, savings, and system health.

7. MAINTENANCE
The Client is responsible for keeping solar panels free from excessive shading and debris. The Company offers annual maintenance packages.

8. UTILITY INTERCONNECTION
The Company will coordinate with the local utility for net metering approval. Energy credits will be applied to the Client's utility bill per local regulations.

9. CANCELLATION
Client may cancel this Agreement within 3 business days of signing without penalty. Cancellations after this period may be subject to restocking and labor fees.

10. GOVERNING LAW
This Agreement shall be governed by the laws of the State of ${state}.

By signing below, the Client acknowledges they have read, understood, and agree to all terms and conditions set forth in this Agreement.`;
}

export function getContracts(): Contract[] {
  return [..._contracts];
}

export function addContract(contract: Contract): void {
  _contracts.push(contract);
}

export function deleteContract(projectNumber: string): void {
  _contracts = _contracts.filter((c) => c.projectNumber !== projectNumber);
}

export function updateContractStatus(projectNumber: string, status: Contract["status"], signedDate?: string): void {
  const c = _contracts.find((c) => c.projectNumber === projectNumber);
  if (c) {
    c.status = status;
    if (signedDate) c.signedDate = signedDate;
  }
}

export function findContract(projectNumber: string, uniqueCode: string): Contract | null {
  return (
    _contracts.find(
      (c) =>
        c.projectNumber.toLowerCase() === projectNumber.toLowerCase() &&
        c.uniqueCode.toLowerCase() === uniqueCode.toLowerCase()
    ) || null
  );
}

export function generateProjectNumber(): string {
  const year = new Date().getFullYear();
  const existing = _contracts.filter((c) => c.projectNumber.startsWith(`SOL-${year}`));
  const nextNum = existing.length + 1;
  return `SOL-${year}-${String(nextNum).padStart(3, "0")}`;
}

export function generateUniqueCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 7; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  // Ensure unique
  const existing = _contracts.find((c) => c.uniqueCode === code);
  if (existing) return generateUniqueCode();
  return code;
}

export function generateContractFromForm(data: {
  clientName: string;
  address: string;
  systemSize: string;
  panelCount: number;
  totalCost: string;
  monthlyPayment: string;
  installationDate: string;
  warrantyYears: number;
  state: string;
  attachments?: Attachment[];
}): Contract {
  const projectNumber = generateProjectNumber();
  const uniqueCode = generateUniqueCode();
  return {
    projectNumber,
    uniqueCode,
    clientName: data.clientName,
    address: data.address,
    systemSize: data.systemSize,
    panelCount: data.panelCount,
    totalCost: data.totalCost,
    monthlyPayment: data.monthlyPayment,
    installationDate: data.installationDate,
    warrantyYears: data.warrantyYears,
    status: "pending",
    attachments: data.attachments || [],
    contractText: generateContractText(
      data.clientName,
      data.address,
      data.panelCount,
      data.systemSize,
      data.totalCost,
      data.monthlyPayment,
      data.installationDate,
      data.state
    ),
  };
}
